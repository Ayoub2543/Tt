# RideTN — Ride-hailing MVP

A ride-hailing platform for Tunisia, now with a real backend: SQLite persistence,
JWT authentication, a live Leaflet/OpenStreetMap for pickup and destination, and
a swappable payment provider.

## Included
- Passenger, driver, and admin roles with phone/password signup and login
- SQLite database (drivers, passengers, rides persist across restarts)
- Real map (OpenStreetMap via Leaflet, no API key needed) for setting pickup/destination
- Great-circle distance calculation and fare estimation in TND
- Ride lifecycle: requested → accepted → started → completed (or cancelled)
- Post-ride payment (mock provider, swappable for a real gateway) and 1-5 star ratings

## Run locally
Requirements: Node.js 20+

```bash
cd backend
npm install
npm run seed     # creates demo drivers + admin account
npm start
```

Open http://localhost:3000

Demo logins:
- Driver: `20111222` / `demo1234` (or `20333444`, `20555666`, same password)
- Admin: `admin` / `admin1234`
- Passenger: sign up with any phone number

## Deploy (free tier, ~3 minutes)

### Option A — Render
1. Push this folder to a GitHub repo.
2. On [render.com](https://render.com), click New → Blueprint, point it at the repo.
   It reads `render.yaml` automatically and sets up the service, including a
   generated `JWT_SECRET`.
3. Render builds and starts the app; you get a public URL like
   `https://ridetn.onrender.com`.

### Option B — Railway
1. Push this folder to a GitHub repo.
2. On [railway.app](https://railway.app), New Project → Deploy from GitHub repo.
   It reads `railway.json` automatically.
3. Add a `JWT_SECRET` environment variable in the Railway dashboard (any random string).

### Option C — Docker (any host: Fly.io, a VPS, etc.)
```bash
docker build -t ridetn -f backend/Dockerfile .
docker run -p 3000:3000 -e JWT_SECRET=your-secret ridetn
```

## Before real-world launch
- Replace the mock payment provider (`backend/payments.js`) with a real gateway
  available in Tunisia (e.g. Flouci, Konnect, ClicToPay) — needs a merchant account.
- Switch SQLite to PostgreSQL if you expect concurrent write load beyond a single instance.
- Add rate limiting, HTTPS (handled automatically by Render/Railway), and audit logs.
- Driver document verification and background checks.
- Legal/regulatory review for ride-hailing in Tunisia.

## Production roadmap
See `docs/roadmap.md` for phased scaling plans (real-time location via WebSocket,
dynamic pricing, courier product, etc.).
