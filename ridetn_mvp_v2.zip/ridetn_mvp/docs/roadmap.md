# Production roadmap

## Phase 1 — MVP
- Web passenger/driver/admin interfaces
- Ride request and matching
- Fare calculation

## Phase 2 — Real infrastructure
- PostgreSQL + migrations
- Redis for real-time state
- WebSocket location updates
- Secure authentication and role-based access
- Map/geocoding/routing provider

## Phase 3 — Operations
- Driver onboarding and document review
- Support tickets
- Fraud/risk controls
- Trip receipts
- Promo codes

## Phase 4 — Payments
- Integrate a payment provider available for the target market
- Cash option if legally/operationally appropriate
- Reconciliation and refunds

## Phase 5 — Scale
- City zones and dynamic pricing
- Scheduled rides
- Airport/corporate rides
- Courier/delivery product
- Analytics and automated driver payouts
