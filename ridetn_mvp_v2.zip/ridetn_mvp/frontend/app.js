const $=s=>document.querySelector(s);
let token=localStorage.getItem('ridetn_token')||null;
let user=JSON.parse(localStorage.getItem('ridetn_user')||'null');
let authMode='login', authRole='passenger';
let pickup=null, dest=null, bookMap, pickupMarker, destMarker;

async function api(url,opt={}){
  const r=await fetch(url,{...opt,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{}),...(opt.headers||{})}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(d.error||'Request failed');
  return d;
}

// ---------- Auth screen ----------
document.querySelectorAll('.auth-tab').forEach(b=>b.onclick=()=>{
  authMode=b.dataset.mode;
  document.querySelectorAll('.auth-tab').forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  $('#signupRole').style.display=authMode==='signup'?'flex':'none';
  $('#nameField').style.display=authMode==='signup'?'block':'none';
  $('#driverFields').style.display=(authMode==='signup'&&authRole==='driver')?'block':'none';
  $('#authSubmit').textContent=authMode==='signup'?'Sign up':'Log in';
  $('#authError').textContent='';
});
document.querySelectorAll('.role-btn').forEach(b=>b.onclick=()=>{
  authRole=b.dataset.role;
  document.querySelectorAll('.role-btn').forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  $('#driverFields').style.display=authRole==='driver'?'block':'none';
});

$('#authForm').onsubmit=async(e)=>{
  e.preventDefault();
  const err=$('#authError'); err.textContent='';
  try{
    let d;
    if(authMode==='signup'){
      d=await api('/api/auth/signup',{method:'POST',body:JSON.stringify({
        name:$('#a_name').value, phone:$('#a_phone').value, password:$('#a_password').value,
        role:authRole, car:$('#a_car').value, plate:$('#a_plate').value
      })});
    }else{
      d=await api('/api/auth/login',{method:'POST',body:JSON.stringify({phone:$('#a_phone').value,password:$('#a_password').value})});
    }
    token=d.token; user=d.user;
    localStorage.setItem('ridetn_token',token);
    localStorage.setItem('ridetn_user',JSON.stringify(user));
    enterApp();
  }catch(ex){ err.textContent=ex.message; }
};

$('#logout').onclick=()=>{
  token=null; user=null;
  localStorage.removeItem('ridetn_token'); localStorage.removeItem('ridetn_user');
  $('#app').style.display='none'; $('#auth').style.display='flex';
};

function enterApp(){
  $('#auth').style.display='none';
  $('#app').style.display='block';
  const nav=$('#nav');
  nav.querySelectorAll('.tab').forEach(t=>t.style.display='none');
  if(user.role==='admin'){ nav.querySelector('[data-tab="admin"]').style.display='inline-block'; showTab('admin'); }
  else if(user.role==='driver'){ nav.querySelector('[data-tab="driver"]').style.display='inline-block'; showTab('driver'); }
  else { nav.querySelector('[data-tab="passenger"]').style.display='inline-block'; showTab('passenger'); initMap(); }
}

function showTab(name){
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));
  document.querySelectorAll('.view').forEach(v=>v.classList.toggle('active',v.id===name));
  if(name==='passenger') setTimeout(()=>{initMap();refreshPassenger();},0);
  if(name==='driver') refreshDriver();
  if(name==='admin') refreshAdmin();
}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));

// ---------- Map ----------
function initMap(){
  if(bookMap) return;
  bookMap=L.map('bookMap',{zoomControl:false}).setView([36.8065,10.1815],12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap'}).addTo(bookMap);
  bookMap.on('click', e=>{
    if(!pickup){
      pickup={lat:e.latlng.lat,lng:e.latlng.lng};
      pickupMarker=L.marker(pickup,{title:'Pickup'}).addTo(bookMap).bindPopup('Pickup').openPopup();
    } else if(!dest){
      dest={lat:e.latlng.lat,lng:e.latlng.lng};
      destMarker=L.marker(dest,{title:'Destination'}).addTo(bookMap).bindPopup('Destination').openPopup();
    } else {
      bookMap.removeLayer(pickupMarker); bookMap.removeLayer(destMarker);
      pickup={lat:e.latlng.lat,lng:e.latlng.lng}; dest=null;
      pickupMarker=L.marker(pickup,{title:'Pickup'}).addTo(bookMap).bindPopup('Pickup').openPopup();
    }
  });
}

// ---------- Passenger ----------
$('#estimate').onclick=async()=>{
  if(!pickup||!dest){ $('#pstatus').textContent='Set both pickup and destination on the map first'; return; }
  const d=await api(`/api/estimate?pickupLat=${pickup.lat}&pickupLng=${pickup.lng}&destLat=${dest.lat}&destLng=${dest.lng}`);
  $('#fare').textContent=`Estimated fare: ${d.fareTnd.toFixed(2)} DT`+(d.etaMinutes?` • driver ~${d.etaMinutes} min away`:'');
};

$('#request').onclick=async()=>{
  const status=$('#pstatus');
  if(!pickup||!dest){ status.textContent='Set both pickup and destination on the map first'; return; }
  try{
    const d=await api('/api/rides',{method:'POST',body:JSON.stringify({
      pickup:'Pickup pin', pickupLat:pickup.lat, pickupLng:pickup.lng,
      destination:'Destination pin', destLat:dest.lat, destLng:dest.lng
    })});
    status.style.color='';
    status.textContent=`Ride ${d.id} requested.`+(d.eta_minutes?` A driver is about ${d.eta_minutes} min away.`:' Looking for a driver…');
    refreshPassenger();
  }catch(ex){ status.style.color='#b91c1c'; status.textContent=ex.message; }
};

function statusLabel(s){ return {requested:'Requested',accepted:'Accepted',started:'In progress',completed:'Completed',cancelled:'Cancelled'}[s]||s; }

async function refreshPassenger(){
  const rs=await api('/api/rides');
  $('#rides').innerHTML=rs.map(r=>`<div class="ride">
    <b>${r.pickup} → ${r.destination}</b><br>
    <span class="muted">${r.fare_tnd.toFixed(2)} DT • ${r.distance_km.toFixed(1)} km${r.eta_minutes&&r.status==='accepted'?` • ETA ${r.eta_minutes} min`:''}</span><br>
    <span class="badge">${statusLabel(r.status)}</span>
    ${r.status==='completed'&&r.payment_status!=='paid'?`<button class="pay-btn" onclick="payRide('${r.id}')">Pay ${r.fare_tnd.toFixed(2)} DT</button>`:''}
    ${r.payment_status==='paid'?'<span class="muted"> • paid</span>':''}
    ${r.status==='completed'&&!r.rating?`<div class="rate">${[1,2,3,4,5].map(n=>`<button class="star" onclick="rateRide('${r.id}',${n})">★</button>`).join('')}</div>`:''}
    ${r.rating?`<span class="muted"> • you rated ${r.rating}★</span>`:''}
  </div>`).join('')||'<p class="muted">No rides yet.</p>';
}

window.payRide=async(id)=>{ try{ await api('/api/rides/'+id+'/pay',{method:'POST'}); refreshPassenger(); }catch(ex){ alert(ex.message); } };
window.rateRide=async(id,stars)=>{ try{ await api('/api/rides/'+id+'/rate',{method:'POST',body:JSON.stringify({rating:stars})}); refreshPassenger(); }catch(ex){ alert(ex.message); } };

// ---------- Driver ----------
async function refreshDriver(){
  $('#driverName').textContent=user.name;
  const ds=await api('/api/drivers');
  const mine=ds.find(d=>d.name===user.name);
  if(mine){
    $('#driverRating').textContent=mine.rating.toFixed(2)+' ★';
    $('#earnings').textContent=mine.earnings.toFixed(2)+' DT';
    $('#driverToggle').textContent=mine.online?'ONLINE':'OFFLINE';
    $('#driverToggle').classList.toggle('off',!mine.online);
    $('#driverToggle').dataset.id=mine.id;
  }
  const rs=await api('/api/rides');
  const available=rs.filter(r=>r.status==='requested');
  $('#incoming').innerHTML=available.map(r=>`<div class="incoming-card">
    <b>${r.pickup} → ${r.destination}</b>
    <p class="muted">${r.distance_km.toFixed(1)} km • ${r.fare_tnd.toFixed(2)} DT</p>
    <button class="accept" onclick="acceptRide('${r.id}')">Accept</button>
  </div>`).join('')||'<p class="muted">Waiting for requests…</p>';

  const active=rs.filter(r=>['accepted','started'].includes(r.status));
  $('#active').innerHTML=active.map(r=>`<div class="incoming-card">
    <b>${r.pickup} → ${r.destination}</b>
    <p class="muted">${r.distance_km.toFixed(1)} km • ${r.fare_tnd.toFixed(2)} DT • ${statusLabel(r.status)}</p>
    ${r.status==='accepted'?`<button class="accept" onclick="setStatus('${r.id}','started')">Start ride</button> <button class="action" onclick="setStatus('${r.id}','cancelled')">Cancel</button>`:''}
    ${r.status==='started'?`<button class="accept" onclick="setStatus('${r.id}','completed')">Complete ride</button>`:''}
  </div>`).join('')||'<p class="muted">No active ride.</p>';
}

window.acceptRide=async(id)=>{ try{ await api('/api/rides/'+id+'/accept',{method:'POST'}); refreshDriver(); }catch(ex){ alert(ex.message); } };
window.setStatus=async(id,status)=>{ try{ await api('/api/rides/'+id+'/status',{method:'POST',body:JSON.stringify({status})}); refreshDriver(); }catch(ex){ alert(ex.message); } };

$('#driverToggle').onclick=async()=>{
  const id=$('#driverToggle').dataset.id;
  if(!id) return;
  await api('/api/drivers/'+id+'/toggle',{method:'POST'});
  refreshDriver();
};

// ---------- Admin ----------
async function refreshAdmin(){
  const [summary,rs]=await Promise.all([api('/api/admin/summary'),api('/api/rides')]);
  $('#driverCount').textContent=summary.driverCount;
  $('#onlineCount').textContent=summary.onlineCount;
  $('#rideCount').textContent=summary.rideCount;
  $('#adminRides').innerHTML=rs.map(r=>`<div class="ride"><b>${r.id}</b> — ${r.pickup} → ${r.destination}<br>
    <span class="muted">${r.fare_tnd.toFixed(2)} DT</span> <span class="badge">${statusLabel(r.status)}</span></div>`
  ).join('')||'<p class="muted">No rides.</p>';
}

// ---------- Boot ----------
if(token&&user) enterApp();
setInterval(()=>{
  if(!token) return;
  if($('#driver').classList.contains('active')) refreshDriver();
  if($('#admin').classList.contains('active')) refreshAdmin();
  if($('#passenger').classList.contains('active')) refreshPassenger();
},4000);
