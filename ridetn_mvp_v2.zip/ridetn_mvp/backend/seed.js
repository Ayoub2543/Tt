import crypto from 'crypto';
import { db } from './db.js';
import { hashPassword } from './auth.js';

const id = (prefix) => `${prefix}${crypto.randomBytes(4).toString('hex')}`;

const demoDrivers = [
  { name: 'Ahmed', phone: '20111222', car: 'Toyota Yaris', plate: '123 تونس 4567', lat: 36.8065, lng: 10.1815 },
  { name: 'Mohamed', phone: '20333444', car: 'Renault Clio', plate: '456 تونس 7788', lat: 36.8189, lng: 10.1658 },
  { name: 'Sami', phone: '20555666', car: 'Peugeot 208', plate: '789 تونس 1122', lat: 36.8628, lng: 10.3236 }
];

for (const d of demoDrivers) {
  const existing = db.prepare('SELECT id FROM users WHERE phone = ?').get(d.phone);
  if (existing) continue;
  const userId = id('u_');
  db.prepare('INSERT INTO users (id, name, phone, password_hash, role, created_at) VALUES (?,?,?,?,?,?)')
    .run(userId, d.name, d.phone, hashPassword('demo1234'), 'driver', new Date().toISOString());
  const driverId = id('d_');
  db.prepare('INSERT INTO drivers (id, user_id, car, plate, online, lat, lng) VALUES (?,?,?,?,1,?,?)')
    .run(driverId, userId, d.car, d.plate, d.lat, d.lng);
}

const adminExisting = db.prepare('SELECT id FROM users WHERE phone = ?').get('admin');
if (!adminExisting) {
  db.prepare('INSERT INTO users (id, name, phone, password_hash, role, created_at) VALUES (?,?,?,?,?,?)')
    .run(id('u_'), 'Admin', 'admin', hashPassword('admin1234'), 'admin', new Date().toISOString());
}

console.log('Seeded demo drivers (phone/password): 20111222/demo1234, 20333444/demo1234, 20555666/demo1234');
console.log('Seeded admin (phone/password): admin/admin1234');
