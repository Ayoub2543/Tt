// Payment provider abstraction. Swap `activeProvider` for a real gateway
// (e.g. Flouci, Konnect, ClicToPay — common providers for Tunisia) once
// you have a merchant account. Every provider must implement `charge`.

const mockProvider = {
  name: 'mock',
  async charge({ amountTnd, rideId }) {
    // Simulates a payment gateway call. Always succeeds after a short delay.
    await new Promise(r => setTimeout(r, 300));
    return { success: true, reference: `MOCK-${rideId}-${Date.now()}`, amountTnd };
  }
};

const providers = { mock: mockProvider };
export const activeProvider = providers[process.env.PAYMENT_PROVIDER || 'mock'];
