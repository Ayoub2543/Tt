import express from 'express';
import cors from 'cors';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { db } from './db.js';
import { hashPassword, verifyPassword, signToken, authRequired, requireRole } from './auth.js';
import { activeProvider } from './payments.js';

const app = express();
app.use(cors());
app.use(express.json());
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname, '../frontend')));

const id = (prefix) => `${prefix}${crypto.randomBytes(4).toString('hex')}`;

function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function estimateFare(distanceKm) {
  const base = 2.0, perKm = 1.2, service = 0.8;
  return Math.max(4, +(base + distanceKm * perKm + service).toFixed(2));
}

function estimateEtaMinutes(driverDistanceKm) {
  return Math.max(1, Math.round((driverDistanceKm / 28) * 60));
}

function findNearestOnlineDriver(lat, lng) {
  const online = db.prepare('SELECT * FROM drivers WHERE online = 1').all();
  if (!online.length) return null;
  return online
    .map(d => ({ ...d, distanceKm: haversineKm(lat, lng, d.lat, d.lng) }))
    .sort((a, b) => a.distanceKm - b.distanceKm)[0];
}

// ---------- Auth ----------

app.post('/api/auth/signup', (req, res) => {
  const { name, phone, password, role, car, plate, lat, lng } = req.body;
  if (!name || !phone || !password || !role) return res.status(400).json({ error: 'Missing signup fields' });
  if (!['passenger', 'driver'].includes(role)) return res.status(400).json({ error: 'Invalid role' });
  const existing = db.prepare('SELECT id FROM users WHERE phone = ?').get(phone);
  if (existing) return res.status(409).json({ error: 'Phone number already registered' });

  const userId = id('u_');
  db.prepare('INSERT INTO users (id, name, phone, password_hash, role, created_at) VALUES (?,?,?,?,?,?)')
    .run(userId, name, phone, hashPassword(password), role, new Date().toISOString());

  if (role === 'driver') {
    if (!car || !plate) return res.status(400).json({ error: 'Driver signup requires car and plate' });
    const driverId = id('d_');
    db.prepare('INSERT INTO drivers (id, user_id, car, plate, online, lat, lng) VALUES (?,?,?,?,0,?,?)')
      .run(driverId, userId, car, plate, lat ?? 36.8065, lng ?? 10.1815);
  }

  const user = { id: userId, role, name };
  res.status(201).json({ token: signToken(user), user });
});

app.post('/api/auth/login', (req, res) => {
  const { phone, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
  if (!user || !verifyPassword(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid phone or password' });
  }
  res.json({ token: signToken(user), user: { id: user.id, role: user.role, name: user.name } });
});

// ---------- Drivers ----------

app.get('/api/admin/summary', authRequired, requireRole('admin'), (_req, res) => {
  const driverCount = db.prepare('SELECT COUNT(*) c FROM drivers').get().c;
  const onlineCount = db.prepare('SELECT COUNT(*) c FROM drivers WHERE online = 1').get().c;
  const rideCount = db.prepare('SELECT COUNT(*) c FROM rides').get().c;
  res.json({ driverCount, onlineCount, rideCount });
});

app.get('/api/drivers', authRequired, (_req, res) => {
  const rows = db.prepare(`
    SELECT d.id, u.name, d.car, d.plate, d.online, d.rating, d.earnings, d.lat, d.lng
    FROM drivers d JOIN users u ON u.id = d.user_id
  `).all();
  res.json(rows);
});

app.post('/api/drivers/:id/toggle', authRequired, requireRole('driver'), (req, res) => {
  const d = db.prepare('SELECT * FROM drivers WHERE id = ?').get(req.params.id);
  if (!d) return res.status(404).json({ error: 'Driver not found' });
  db.prepare('UPDATE drivers SET online = ? WHERE id = ?').run(d.online ? 0 : 1, d.id);
  res.json({ ...d, online: d.online ? 0 : 1 });
});

// ---------- Rides ----------

app.get('/api/rides', authRequired, (req, res) => {
  const { status } = req.query;
  let rows;
  if (req.user.role === 'admin') {
    rows = db.prepare('SELECT * FROM rides ORDER BY created_at DESC').all();
  } else if (req.user.role === 'driver') {
    rows = db.prepare('SELECT * FROM rides WHERE status = ? OR driver_id = (SELECT id FROM drivers WHERE user_id = ?)')
      .all('requested', req.user.id);
  } else {
    rows = db.prepare('SELECT * FROM rides WHERE passenger_id = ?').all(req.user.id);
  }
  res.json(status ? rows.filter(r => r.status === status) : rows);
});

app.get('/api/estimate', authRequired, (req, res) => {
  const pickupLat = Number(req.query.pickupLat), pickupLng = Number(req.query.pickupLng);
  const destLat = Number(req.query.destLat), destLng = Number(req.query.destLng);
  const distanceKm = [pickupLat, pickupLng, destLat, destLng].every(Number.isFinite)
    ? Math.max(0.3, haversineKm(pickupLat, pickupLng, destLat, destLng))
    : Math.max(0.3, Number(req.query.km) || 5);
  const nearest = pickupLat ? findNearestOnlineDriver(pickupLat, pickupLng) : null;
  res.json({
    distanceKm: +distanceKm.toFixed(2),
    fareTnd: estimateFare(distanceKm),
    etaMinutes: nearest ? estimateEtaMinutes(nearest.distanceKm) : null
  });
});

app.post('/api/rides', authRequired, requireRole('passenger'), (req, res) => {
  const { pickup, pickupLat, pickupLng, destination, destLat, destLng } = req.body;
  if (!pickup || !destination || ![pickupLat, pickupLng, destLat, destLng].every(Number.isFinite)) {
    return res.status(400).json({ error: 'Missing pickup/destination coordinates' });
  }
  const distanceKm = Math.max(0.3, haversineKm(pickupLat, pickupLng, destLat, destLng));
  const fareTnd = estimateFare(distanceKm);
  const rideId = id('R');
  const nearest = findNearestOnlineDriver(pickupLat, pickupLng);
  const etaMinutes = nearest ? estimateEtaMinutes(nearest.distanceKm) : null;

  db.prepare(`INSERT INTO rides
    (id, passenger_id, pickup, pickup_lat, pickup_lng, destination, destination_lat, destination_lng,
     distance_km, fare_tnd, status, eta_minutes, payment_status, created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,'requested',?,'unpaid',?)`)
    .run(rideId, req.user.id, pickup, pickupLat, pickupLng, destination, destLat, destLng,
      distanceKm, fareTnd, etaMinutes, new Date().toISOString());

  res.status(201).json(db.prepare('SELECT * FROM rides WHERE id = ?').get(rideId));
});

app.post('/api/rides/:id/accept', authRequired, requireRole('driver'), (req, res) => {
  const driver = db.prepare('SELECT * FROM drivers WHERE user_id = ?').get(req.user.id);
  const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(req.params.id);
  if (!ride || !driver) return res.status(404).json({ error: 'Ride or driver not found' });
  if (!driver.online || ride.status !== 'requested') return res.status(409).json({ error: 'Ride is no longer available' });
  const etaMinutes = estimateEtaMinutes(haversineKm(driver.lat, driver.lng, ride.pickup_lat, ride.pickup_lng));
  db.prepare('UPDATE rides SET status = ?, driver_id = ?, eta_minutes = ? WHERE id = ?')
    .run('accepted', driver.id, etaMinutes, ride.id);
  res.json(db.prepare('SELECT * FROM rides WHERE id = ?').get(ride.id));
});

app.post('/api/rides/:id/status', authRequired, (req, res) => {
  const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(req.params.id);
  if (!ride) return res.status(404).json({ error: 'Ride not found' });
  const allowed = { accepted: ['started', 'cancelled'], started: ['completed'], requested: ['cancelled'] };
  if (!allowed[ride.status]?.includes(req.body.status)) return res.status(400).json({ error: 'Invalid status transition' });
  db.prepare('UPDATE rides SET status = ? WHERE id = ?').run(req.body.status, ride.id);
  if (req.body.status === 'completed' && ride.driver_id) {
    db.prepare('UPDATE drivers SET earnings = earnings + ? WHERE id = ?').run(+(ride.fare_tnd * 0.8).toFixed(2), ride.driver_id);
  }
  res.json(db.prepare('SELECT * FROM rides WHERE id = ?').get(ride.id));
});

app.post('/api/rides/:id/pay', authRequired, requireRole('passenger'), async (req, res) => {
  const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(req.params.id);
  if (!ride) return res.status(404).json({ error: 'Ride not found' });
  if (ride.status !== 'completed') return res.status(400).json({ error: 'Ride must be completed before payment' });
  if (ride.payment_status === 'paid') return res.status(409).json({ error: 'Ride already paid' });

  try {
    const result = await activeProvider.charge({ amountTnd: ride.fare_tnd, rideId: ride.id });
    db.prepare('UPDATE rides SET payment_status = ?, payment_provider = ? WHERE id = ?')
      .run(result.success ? 'paid' : 'failed', activeProvider.name, ride.id);
    res.json({ ...result, ride: db.prepare('SELECT * FROM rides WHERE id = ?').get(ride.id) });
  } catch {
    res.status(502).json({ error: 'Payment provider error' });
  }
});

app.post('/api/rides/:id/rate', authRequired, requireRole('passenger'), (req, res) => {
  const ride = db.prepare('SELECT * FROM rides WHERE id = ?').get(req.params.id);
  if (!ride) return res.status(404).json({ error: 'Ride not found' });
  if (ride.status !== 'completed') return res.status(400).json({ error: 'Ride must be completed before rating' });
  const stars = Number(req.body.rating);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) return res.status(400).json({ error: 'Rating must be 1-5' });

  db.prepare('UPDATE rides SET rating = ? WHERE id = ?').run(stars, ride.id);
  if (ride.driver_id) {
    const d = db.prepare('SELECT * FROM drivers WHERE id = ?').get(ride.driver_id);
    const newRating = +(((d.rating * d.rated_count) + stars) / (d.rated_count + 1)).toFixed(2);
    db.prepare('UPDATE drivers SET rating = ?, rated_count = rated_count + 1 WHERE id = ?').run(newRating, d.id);
  }
  res.json(db.prepare('SELECT * FROM rides WHERE id = ?').get(ride.id));
});

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`RideTN running on port ${PORT}`));
